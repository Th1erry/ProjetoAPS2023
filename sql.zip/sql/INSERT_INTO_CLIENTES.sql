INSERT INTO LOJA_SUPLEMENTOS.CLIENTES VALUES ( 1 , "45319799828", "Fernando Silva", "fernando@email.com", "11953703788", "Rua dos testes, 22");
